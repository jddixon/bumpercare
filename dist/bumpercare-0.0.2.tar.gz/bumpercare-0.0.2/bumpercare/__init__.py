# bumpercare/__init__.py

""" default proj desc """

__version__ = '0.0.2'
__version_date__ = '2017-04-06'

__all__ = ['__version__', '__version_date__']
